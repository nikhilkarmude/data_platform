class Dataquality

    def rule1(sql):
        pass
        result = snowpark.sql(sql)
        print(result)


    def rule2():
        pass